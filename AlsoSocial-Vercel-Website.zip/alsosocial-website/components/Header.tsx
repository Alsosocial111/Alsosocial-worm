"use client";
import Link from "next/link";
import {useState} from "react";
export default function Header(){
 const [open,setOpen]=useState(false);
 return <header className="site-header"><div className="nav-wrap">
  <Link href="/" className="wordmark" aria-label="AlsoSocial home"><span>Also</span><b>Social</b><i>®</i></Link>
  <button className="menu-toggle" onClick={()=>setOpen(!open)} aria-label="Toggle navigation"><span/><span/></button>
  <nav className={open?"nav-links open":"nav-links"}>
   <Link href="/" onClick={()=>setOpen(false)}>Home</Link>
   <Link href="/#what-we-do" onClick={()=>setOpen(false)}>What we do</Link>
   <Link href="/contact" onClick={()=>setOpen(false)}>Contact</Link>
   <Link href="/contact#booking" className="nav-cta" onClick={()=>setOpen(false)}>Let’s talk <span>↗</span></Link>
  </nav>
 </div></header>
}

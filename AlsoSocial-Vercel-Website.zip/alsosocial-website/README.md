# AlsoSocial — Agency Website

A responsive Next.js website designed around the deep teal / cyan palette in the supplied reference.

## Pages and navigation
- **Home** (`/`) — animated hero, tool strip, studio introduction, What we do, industries and CTA.
- **What we do** — a navigation link that scrolls to the services section on the home page (`/#what-we-do`).
- **Contact** (`/contact`) — dedicated contact page with booking enquiry form.

## Run locally
1. Install Node.js 20.9+.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env.local` and fill in your SMTP details.
4. Run `npm run dev` and open http://localhost:3000.

## Booking form email setup
The form posts to the server-side route `app/api/booking/route.ts`. The recipient address is read only from the `BOOKING_TO` environment variable. It is not included in the website UI or browser-side JavaScript.

Set these environment variables in **Vercel → Project → Settings → Environment Variables** (and locally in `.env.local`):
- `SMTP_HOST` — your mail provider's SMTP host
- `SMTP_PORT` — usually `587` (or `465` for SSL)
- `SMTP_SECURE` — `false` for 587, `true` for 465
- `SMTP_USER` — SMTP username
- `SMTP_PASS` — SMTP app password / SMTP credential
- `MAIL_FROM` — verified sender address, e.g. `AlsoSocial Website <website@yourdomain.com>`
- `BOOKING_TO` — the private inbox that should receive enquiries

Use an SMTP account/domain you control. Some providers require an app password or SMTP access to be enabled. Do not commit `.env.local` or secrets to GitHub. The `.env` files are ignored by Git.

## Deploy to GitHub + Vercel
1. Create a new GitHub repository and upload the contents of this project (not the ZIP itself).
2. In Vercel, choose **Add New → Project**, import that GitHub repository and keep the framework preset as **Next.js**.
3. Add the environment variables above before deploying.
4. Click **Deploy**. Vercel will build the Next.js app and host the API route with the site.

## Before launch
- Confirm SMTP credentials and send a test enquiry.
- Replace the sender address with an address verified by your email provider.
- Add your final domain in Vercel and update the metadata URL in `app/layout.tsx` if needed.
- The “Talk to us” links intentionally open `varun@alsosocial.com` using the visitor's email app.

import {NextResponse} from "next/server";
import nodemailer from "nodemailer";
export const runtime = "nodejs";
export async function POST(req:Request){
 try {
  const data=await req.formData();
  // Honeypot field: silently accept bot submissions without sending email.
  if(String(data.get("website")||"").trim()) return NextResponse.redirect(new URL("/contact?sent=1",req.url),303);
  const name=String(data.get("name")||"").trim();
  const email=String(data.get("email")||"").trim();
  const company=String(data.get("company")||"").trim();
  const service=String(data.get("service")||"").trim();
  const message=String(data.get("message")||"").trim();
  if(name.length<2 || !/^\S+@\S+\.\S+$/.test(email) || message.length<10 || !service) return NextResponse.json({error:"Please complete all required fields with valid details."},{status:400});
  const {SMTP_HOST,SMTP_PORT,SMTP_SECURE,SMTP_USER,SMTP_PASS,MAIL_FROM,BOOKING_TO}=process.env;
  if(!SMTP_HOST||!SMTP_USER||!SMTP_PASS||!MAIL_FROM||!BOOKING_TO) return NextResponse.json({error:"The enquiry form is not configured yet. Please email us directly."},{status:503});
  const transporter=nodemailer.createTransport({host:SMTP_HOST,port:Number(SMTP_PORT||587),secure:SMTP_SECURE==="true",auth:{user:SMTP_USER,pass:SMTP_PASS}});
  await transporter.sendMail({from:MAIL_FROM,to:BOOKING_TO,replyTo:email,subject:`New AlsoSocial enquiry — ${service}`,text:`New website enquiry

Name: ${name}
Email: ${email}
Company: ${company||"Not provided"}
Service: ${service}

Message:
${message}`,html:`<h2>New website enquiry</h2><p><b>Name:</b> ${escapeHtml(name)}</p><p><b>Email:</b> ${escapeHtml(email)}</p><p><b>Company:</b> ${escapeHtml(company||"Not provided")}</p><p><b>Service:</b> ${escapeHtml(service)}</p><p><b>Message:</b><br/>${escapeHtml(message).replace(/
/g,"<br/>")}</p>`});
  return NextResponse.redirect(new URL("/contact?sent=1",req.url),303);
 } catch(e){console.error("Booking form error",e);return NextResponse.json({error:"Something went wrong. Please try again in a moment."},{status:500});}
}
function escapeHtml(value:string){return value.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]!));}

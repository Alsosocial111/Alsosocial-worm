import type { Metadata } from "next";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
export const metadata: Metadata = {
  title: "AlsoSocial — We Build. We Grow. We Automate.",
  description: "Digital experiences, growth campaigns and intelligent automation by AlsoSocial.",
  metadataBase: new URL("https://alsosocial.com")
};
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body><Header />{children}<Footer /></body></html>;
}
